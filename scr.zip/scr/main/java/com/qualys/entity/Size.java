package com.qualys.entity;

public enum Size {

    REGULAR,
    MEDIUM,
    LARGE
}
