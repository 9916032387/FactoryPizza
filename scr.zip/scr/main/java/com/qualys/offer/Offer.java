package com.qualys.offer;

import com.qualys.entity.Pizza;

public interface Offer {

    Double execute(Pizza pizza);
}
